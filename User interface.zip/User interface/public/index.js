const send  = document.querySelector("#send");

send.addEventListener("click", function(event) {
    const box = document.querySelector("#box");
    const newMsg = box.value;
    box.value = "";
    console.log(newMsg);

    const inbox = document.querySelector("#inbox");
    inbox.innerHTML +=`<div class="flex justify-end"><div class="msg sent">${newMsg}</div></div>`;
    event.preventDefault();
  });
