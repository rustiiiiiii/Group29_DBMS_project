module.exports = {
    content: ["./public/*.{html,js}"],
    theme: {
        extend: {},
    },
    plugins: [],
};
